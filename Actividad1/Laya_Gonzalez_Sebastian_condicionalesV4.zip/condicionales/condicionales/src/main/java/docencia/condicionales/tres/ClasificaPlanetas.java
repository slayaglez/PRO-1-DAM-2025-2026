package docencia.condicionales.tres;

import java.util.Scanner;

/**
 * Clase principal
 * 
 * @author slayaglez
 * @date 28 sept 2025
 * @class Un programa que devuelve un planeta y datos del mismo
 * en base al número introducido
 * 
 */
public class ClasificaPlanetas {
    public static void main(String[] args) {
        // Abro scanner
        Scanner sc = new Scanner(System.in);
        // Pido el número
        System.out.println("==Planetario==\nIntroduce un número del 1 al 8: ");
        int numero = sc.nextInt();
        // Abro dos arrays, uno con los planetas y otro con los datos
        String planetas[] = {"Mercurio", "Venus", "Tierra", "Marte", "Júpiter", "Saturno", "Urano", "Neptuno"};
        String datos[] = {"el planeta más pequeño", "el de mayor temperatura", "el único que alberga vida", "conocido como el planeta rojo", "el más grande de todos", "el que cuyos anillos miden varios miles de kilómetros", "el que en su atmósfera pueden llover diamantes", "el más lejano de todos"};
        // Imprimo la respuesta
        // System.out.println("Su planeta es " + planetas[numero-1] + " y es " + datos[numero-1]);
        switch (numero) {
            case 1: System.out.println(planetas[0]+", "+datos[0]); break;
            case 2: System.out.println(planetas[1]+", "+datos[1]); break;
            case 3: System.out.println(planetas[2]+", "+datos[2]); break;
            case 4: System.out.println(planetas[3]+", "+datos[3]); break;
            case 5: System.out.println(planetas[4]+", "+datos[4]); break;
            case 6: System.out.println(planetas[5]+", "+datos[5]); break;
            case 7: System.out.println(planetas[6]+", "+datos[6]); break;
            case 8: System.out.println(planetas[7]+", "+datos[7]); break;
    
            default: System.out.println("Número incorrecto"); break;
        }
        // Cierro el scanner
        sc.close();
    }
}

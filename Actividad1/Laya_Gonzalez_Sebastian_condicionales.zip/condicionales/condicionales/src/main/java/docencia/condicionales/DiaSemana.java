package docencia.condicionales;

import java.util.Scanner;

public class DiaSemana {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Ingresa un número (1-7): ");
        int dia = sc.nextInt();

        

        sc.close();
    }
}
